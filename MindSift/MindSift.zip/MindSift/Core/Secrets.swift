//
//  Secrets.swift
//  MindSift
//
//  Created by Mustafa TAVASLI on 24.11.2025.
//

import Foundation

struct Secrets {
    // Google AI Studio API Key -- .gitignore ile saklanacak.
    static let geminiAPIKey = "AIzaSyButEXcniRhi_6K6t4-eNAIld_k5X5z4Ro"
}
